document.addEventListener("DOMContentLoaded", () => {
  //---- SEU CÓDIGO ABAIXO ----//
  //---- DESAFIO AULA 2 ----//

  let b = 7;
  let h = 10;
  let A = h * b;
  //---- EXIBIR RESULTADO NA TELA ----//

  exibirResultadoNaTela(A);
});
